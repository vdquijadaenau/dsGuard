# Design System → Token Pipeline for AI Coding Agents
### Process reference & action plan

> **What this solves:** components built by coding agents drift from your design, and fixing
> the drift burns time and tokens. This document describes a system that makes drift
> *structurally hard*, loads design context *only when needed*, and *verifies* output
> deterministically — plus the action plan and the PRDs to write before building it.

---

## 1. The core principle (read this first)

Drift is not primarily a context-loading problem. It is an **architecture** problem. When an
agent re-derives a component's colors, spacing, and states from prose every time — in any
stack — it lands somewhere slightly different every time. No amount of clever lazy-loading
fixes that.

So the strategy is three lines of defense, in priority order:

1. **Make drift structurally hard.** A canonical, machine-readable token set is the single
   source of truth; agents reference tokens by name, never raw values.
2. **Load design context only when needed.** Component detail lives in an on-demand skill,
   not in always-on context.
3. **Verify deterministically after build.** Cheap, code-based checks catch what the model
   can't be trusted to self-grade.

Two consequences worth internalizing:

- **Prose markdown becomes documentation, not the source of truth.** The Claude Design files
  describe *intent and rules*; the token set holds the enforceable *values*.
- **You don't optimize "don't load design files."** Loading one focused reference at the right
  moment is cheap next to a drift-fix loop. The expensive thing is rework.

---

## 2. Architecture (four layers)

| Layer | Purpose | Artifact |
|---|---|---|
| **1. Source of truth** | Canonical design values, stack-agnostic | DTCG JSON token set |
| **2. Generation constraint** | Stop "from scratch"; compose from constrained pieces | Per-stack primitive components (optional, per durable project) |
| **3. On-demand loading** | Give the agent the right component contract only when relevant | One `design-system` Claude Code skill (router + `references/` + `scripts/`) |
| **4. Verification** | Catch drift after build without trusting self-review | Token-lint + visual regression (deterministic) → reviewer subagent (subjective only) |

---

## 3. The pipeline

```
Claude Design markdown ──► DTCG JSON (canonical) ──► Style Dictionary ──► stack output
   (intent + rules)          ($value/$type,            (one config,         (Tailwind v4 @theme,
                              primitive + semantic      many platforms)      CSS-Modules vars,
                              tiers, aliases)                                Svelte vars, plain CSS)
```

- **Author once** in DTCG JSON. Each project compiles its own view.
- **DTCG tiers:** *primitive* tokens (raw values, named by what they are) → *semantic* tokens
  (named by intent, referencing primitives via `{group.token}`). Components reference the
  semantic layer, so they cannot land on a near-but-wrong value.
- **Tailwind v4 note:** Style Dictionary emits a `@theme { … }` block; token group names must
  match Tailwind's namespaces (`color`, `spacing`, `font`, `radius`, `ease`, `breakpoint`) for
  utilities to auto-generate. (Tailwind v3 emits a `tailwind.config.js` instead — same token
  source, different build target.)

---

## 4. The conversion process (one-time, checkpointed)

There is **no turnkey "prose → DTCG" converter**, and you should not want one: extraction is
interpretive (it surfaces hex that should be named tokens, the token/contract split, and
values the docs never specified). A fully automatic black box would launder those judgment
errors into the canonical source, where they poison every future app.

What you build instead is a **repeatable, gated converter**:

1. **Extractor skill** drafts DTCG from the markdown, following the tier rules, and flags every
   invented or ambiguous value in a `$description`.
2. **Validator script** (pure code — cannot rationalize) fails on: any hex outside the
   primitive layer; any unresolved `{reference}`; any `$value`/`$type` mismatch; any token a
   component contract names but the set is missing; duplicate values that should be one alias.
3. **Human review** of the diff. This is the one mandatory non-automated step.
4. **Re-run only when the design system changes** — not per app. Extraction token cost is paid
   rarely.

**More reliable value source — extract from the render, not the prose.** Your CSS is real;
render one page and read computed styles (e.g. a Playwright-based extractor) to capture
*actual* values. Then split authority:

- **Rendered CSS** = source of truth for **values**.
- **Markdown** = source of truth for **intent, names, and component contracts**.

This turns "interpret English into numbers" (error-prone) into "reconcile observed values with
your naming" (a review task).

---

## 5. Verification (defense line 3)

- **Deterministic, zero-token gates** via Claude Code hooks (`PostToolUse` / `Stop`) or skill
  scripts:
  - *Token-lint:* fail any component class containing a hex/px literal instead of a token; fail
    any color outside the approved semantics.
  - *Visual regression:* render the component's states and diff against a baseline. This is the
    **only stack-agnostic** check (it tests rendered output, not the framework). Playwright's
    built-in `toHaveScreenshot()` is free; BackstopJS and Chromatic are alternatives.
- **Reviewer subagent (fresh context)** only for what pixels can't judge — hierarchy, spacing
  rhythm, "does this match intent." Never let the builder grade its own work.

---

## 6. Reuse & distribution (per app)

Reuse is a **packaging** problem, not a conversion one. You do not re-convert markdown per app;
you pull in the finished artifact.

- **Claude Code plugin** — one install drops the `design-system` skill, the token-lint hook,
  and the build script into any project, and seeds the Spec Kit `constitution.md` /
  OpenSpec `project.md` design rules.
- **npm package** — `npm i @you/design-tokens && npm run tokens` emits output for the project's
  stack (choose the Style Dictionary platform at build time).
- **Versioning** — semver the token set. On a design change: bump, rebuild, apps opt in
  deliberately rather than drifting silently.

Per-new-app flow: install plugin → run token build for this stack → skill + lint already there.

---

## 7. Integration with Spec Kit & OpenSpec

- **Spec Kit (greenfield):** put non-negotiables ("all visual values come from tokens; compose
  from primitives; no hardcoded styles") in `.specify/memory/constitution.md` (keep it tiny).
  Use the read-only `/speckit.analyze` as a spec-level design gate before `/speckit.implement`,
  and add the deterministic checks as explicit entries in `tasks.md`.
- **OpenSpec (brownfield):** equivalent rules go in `openspec/project.md`. Write design
  acceptance criteria as testable Given/When/Then scenarios that map onto the token-lint and
  screenshot checks; gate with `/opsx:verify`.

---

## 8. Product Requirement Documents to create

Write these **before** building. Each is a short, testable spec; together they define the
system. (These also become the input to Spec Kit `/speckit.specify` or OpenSpec
`/opsx:propose` when you build the tooling itself.)

### PRD-1 — Design Token System
- **Purpose:** define the canonical DTCG token set.
- **Contents:** tiers (primitive / semantic / optional component); naming conventions; type
  coverage (color, spacing, typography, radius, shadow, motion); theming / dark-mode strategy
  (`outputReferences`); DTCG format-version pin; semver policy.
- **Acceptance:** every value in the design system is represented; no orphan or unresolved
  references; passes the validator.

### PRD-2 — Token Extraction & Validation
- **Purpose:** the gated converter (markdown + rendered CSS → DTCG).
- **Contents:** extractor-skill behavior; the full validator rule set; the render-based value
  extraction + reconciliation step; the human-review gate; re-run triggers.
- **Acceptance:** validator catches every failure class in §4; no token is canonical without
  human sign-off; re-running on an unchanged system is a no-op.

### PRD-3 — Style Dictionary Build
- **Purpose:** compile one source to many stacks.
- **Contents:** source globs; platforms (Tailwind v4 `@theme`, CSS-Modules vars, Svelte vars,
  plain CSS, Tailwind v3 config); namespace mapping; `outputReferences` for theming;
  format-version pinning.
- **Acceptance:** one token change propagates correctly to every target; Tailwind utilities
  generate from token names.

### PRD-4 — Design-System Skill (on-demand loading)
- **Purpose:** give the agent the right component contract cheaply.
- **Contents:** lean router `SKILL.md` (<500 lines); `references/<component>.md` contracts (each
  stripped of literals, referencing tokens only); `scripts/` validators; precise `description`
  field for correct auto-triggering.
- **Acceptance:** only the relevant component file loads; startup metadata footprint is bounded
  (one skill, not one-per-component); contracts contain no raw values.

### PRD-5 — Verification & Lint
- **Purpose:** catch drift after build.
- **Contents:** token-lint rules; Claude Code hook wiring (`PostToolUse`/`Stop`); visual
  regression setup (tool, baselines, viewports, reduced-motion handling); reviewer-subagent
  scope (subjective checks only).
- **Acceptance:** deterministic checks block a known-bad component in CI; subagent is never the
  sole gate for quantifiable properties.

### PRD-6 — Distribution / Plugin
- **Purpose:** make the system reusable in any new app.
- **Contents:** Claude Code plugin contents; npm package contents; install flow; seeding of
  constitution / `project.md`; semver + change/opt-in process.
- **Acceptance:** a fresh app is onboarded (tokens + skill + lint + rules) in one install plus
  one build command.

### PRD-7 — Spec-Tool Integration
- **Purpose:** make design checks part of the spec loop, not an afterthought.
- **Contents:** constitution / `project.md` rule text; `/speckit.analyze` and `/opsx:verify`
  usage; design acceptance criteria as testable scenarios; `tasks.md` entries.
- **Acceptance:** a spec that omits token/visual checks fails analysis/verify before
  implementation.

---

## 9. Sequenced action plan

| Phase | Action | PRD | Output |
|---|---|---|---|
| 0 | Write the PRDs | all | 7 short specs |
| 1 | Extract tokens (colors/type/spacing first, then components) | PRD-1, PRD-2 | canonical DTCG set + validator |
| 2 | Wire Style Dictionary build for your stacks | PRD-3 | per-stack output |
| 3 | Add token-lint + screenshot check as a hook/script | PRD-5 | deterministic gate |
| 4 | Build the `design-system` skill (router + references + scripts) | PRD-4 | on-demand loading |
| 5 | Wire rules into Spec Kit constitution / OpenSpec `project.md` | PRD-7 | spec-loop gate |
| 6 | (Durable projects only) add per-stack primitives | PRD-1 | composition layer |
| 7 | Package as plugin + npm, version it | PRD-6 | reusable artifact |
| 8 | Add the reviewer subagent, scoped to subjective checks | PRD-5 | final review line |

Phases 1–5 attack both drift *and* context cost without touching the "from scratch" problem, so
they pay off even if you never build primitives (phase 6).

---

## 10. Caveats & decisions to watch

- **Validator is load-bearing, the LLM is a drafting aid.** Never let the model's say-so be the
  gate.
- **Pin the DTCG format version** to what Style Dictionary v4 actually supports; the newest
  spec module (2025.10) is not yet fully supported (in progress for v5). An unpinned version
  can break your build.
- **Primitives are real work per stack.** Worth it for durable products; skip for throwaways
  (tokens + skill + verification still carry you).
- **Visual regression has maintenance cost** — baselines, flake from fonts/animation, approval
  workflow. Budget for it.
- **The reviewer subagent is the weakest link.** Use it only for the genuinely subjective
  remainder; keep anything quantifiable (color, spacing, type scale) on deterministic checks.
- **`DESIGN.md` (Google, 2026) is a documentation layer, not a drift fix.** It's still
  interpretive prose; keep DTCG canonical and treat `DESIGN.md` as a modern replacement for the
  current markdown, sitting on top of the tokens.

---

## 11. Tool reference

- **DTCG** — W3C Design Tokens format (JSON `$value`/`$type`/`$description`, `{aliases}`).
- **Style Dictionary v4** — token transformer with first-class DTCG support; one source → many
  platform outputs.
- **Tailwind v4** — CSS-first `@theme` directive; tokens become CSS variables + utilities.
- **Claude Code** — skills (progressive disclosure: metadata always loaded, body/refs on
  demand), subagents (isolated context), hooks (deterministic lifecycle scripts), plugins
  (distribution).
- **Visual regression** — Playwright `toHaveScreenshot()` (free), BackstopJS (OSS), Chromatic
  (component-level).
- **Spec Kit** — `constitution.md`, `/speckit.analyze`, `tasks.md`.
- **OpenSpec** — `project.md`, `/opsx:verify`, Given/When/Then specs.
