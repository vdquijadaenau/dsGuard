# DS-Guard — Generic Design-System Enforcement Engine
### Implementation plan

> **Goal:** a reusable engine that keeps AI-agent-built UI on-design for *any* design system,
> by turning each system's data into a specific, drift-proof skill plus a deterministic
> validator — without being tied to any one design system.
>
> **Non-goal:** being a design system. DS-Guard ships no colours, fonts, or rules of its own.
> (Daybreak, which is an experiment, is **not** part of this design; it appears below only as a
> throwaway test case.)

---

## 1. The core idea (engine vs. data)

Like a spell-checker: an **engine** scans and flags, a **dictionary** says what's correct. The
engine is reusable for any language; the dictionary is per-language.

DS-Guard splits the same way:

- **Engine** (the reusable machinery) — the validator logic, the skill template, the generator,
  the commands, the hook, the reviewer. Knows *how* to enforce, knows *nothing* about your
  brand.
- **Manifest** (per-system data) — one design system's tokens and rules. The dictionary.

The engine reads a manifest and **stamps out a specific skill + validator config** for that
system. So you never hand-write an enforcement skill again — you write a manifest, and the
engine generates the sharp, system-specific artifact. (Specific skills trigger more reliably and
keep their vocabulary in context; we keep that benefit and only genericize the machine that
produces them.)

---

## 2. Architecture

```
  PER-SYSTEM DATA                ENGINE (this plugin)              GENERATED OUTPUT (runtime)
  ───────────────                ────────────────────              ──────────────────────────
  design/                         /dsguard:generate                <name>-design-system/
   ├ tokens/  (DTCG)   ──────►    reads manifest, fills    ──────►  ├ skills/.../SKILL.md  (specific)
   ├ rules.json                   the SKILL template and            ├ scripts/validate.mjs (frozen copy)
   └ references/*.md              emits validator config            ├ validator.config.json
                                                                     └ .claude-plugin/plugin.json
                                                                            │
                                                                            ▼
                                                       installed into an app → skill triggers on
                                                       UI work; PostToolUse hook runs the validator
```

Two artifacts, two lifecycles:

- **The engine is a build-time tool.** Installed once by whoever maintains design systems.
- **The generated `<name>-design-system` is a runtime artifact.** It bundles a *frozen copy* of
  the validator plus its config, so an app only needs the generated plugin — not the engine — to
  be protected. This keeps app projects light and decoupled from the engine's version.

### Engine components

| Component | What it is | Genericity |
|---|---|---|
| `scripts/validate.mjs` | The validator from our prototype, refactored to read its allow-lists from a manifest instead of embedding them | Fully generic |
| `templates/SKILL.md.tmpl` | The skill body with injection slots (`{{colors}}`, `{{type_scale}}`, `{{rules}}`, `{{freeform}}`) | Fully generic |
| `scripts/generate-skill.mjs` | Fills the template + emits `validator.config.json` from a manifest | Fully generic |
| `commands/*.md` | Slash commands: `init`, `generate`, `check`, `review` | Fully generic |
| `hooks/hooks.json` | `PostToolUse`/`Stop` → run the validator on changed files | Fully generic |
| `agents/design-reviewer.md` | Fresh-context subagent for subjective review (hierarchy, rhythm) | Fully generic |

---

## 3. The manifest (per-system data)

Lives in the design system's own repo, never in the engine.

```
design/
├── tokens/            # DTCG JSON — colours, type scale, spacing, radius, shadow, motion
│   ├── primitives.json
│   └── semantic.json
├── rules.json         # the policy the validator enforces (schema below)
└── references/        # optional per-component contracts (markdown), loaded on demand
    └── <component>.md
```

### `rules.json` schema

Designed to cover the common 80% as data, with an escape hatch for the rest:

```json
{
  "name": "acme",
  "casing": "sentence",
  "textAlign": { "banned": ["justify"], "centerOnlyShort": true },
  "type": { "scaleOnly": true, "bodyMinPx": 16 },
  "shadows": { "policy": "allowlist", "allowed": ["sm", "md"] },
  "radius": { "allowed": ["sm", "md", "lg", "full"] },
  "fonts": { "ui": "sans", "editorial": "serif",
             "editorialContexts": ["article body", "marketing hero"] },
  "arbitraryAllowlist": ["max-w-[72ch]"],
  "freeformRules": "Brand teal is fill-only; never body text. Status colour must travel with an icon + label."
}
```

**What genericizes — and what doesn't (be honest about this):**

- **Tokens** → fully data-driven. (This is the DTCG set, and it's why DTCG stops being optional
  once you want generic: it's the dictionary the engine reads.)
- **Common rules** → fit the schema above: casing, banned alignments, shadow/radius allow-lists,
  type policy, font roles. The validator enforces these deterministically.
- **Bespoke rules** → the long tail (e.g. "this colour pairs only with that one in this one
  place"). These cannot be schematized. They live in `freeformRules` and `references/`, where the
  agent reads them but the validator largely **cannot** enforce them. The reviewer subagent and
  visual regression cover what the validator can't.

---

## 4. Can it be a plugin? Yes — two plugins, actually

- **Engine plugin (`ds-guard`)** — the machinery. Installed once, used everywhere.
- **Per-system plugin (`<name>-design-system`)** — *generated* by the engine, published to a
  team marketplace, installed by apps that use that design system.

### Engine plugin layout

```
ds-guard/
├── .claude-plugin/
│   └── plugin.json          # ONLY the manifest goes here
├── commands/                # /dsguard:init  /dsguard:generate  /dsguard:check  /dsguard:review
├── skills/
│   └── ds-guard/SKILL.md    # ambient guidance on authoring manifests & generating
├── agents/
│   └── design-reviewer.md   # fresh-context reviewer subagent
├── hooks/
│   └── hooks.json           # PostToolUse/Stop → validator
├── scripts/
│   ├── validate.mjs         # generic, manifest-driven validator
│   └── generate-skill.mjs   # template → specific skill + validator.config.json
├── templates/
│   └── SKILL.md.tmpl
└── README.md
```

```json
// ds-guard/.claude-plugin/plugin.json   (only "name" is required)
{
  "name": "ds-guard",
  "version": "0.1.0",
  "description": "Generate and enforce a design-system skill + deterministic token validator from a manifest. Design-system-agnostic."
}
```

> **Common mistake to avoid:** only `plugin.json` goes inside `.claude-plugin/`. Every component
> directory (`commands/`, `skills/`, `agents/`, `hooks/`, `scripts/`) sits at the plugin **root**.
> Putting them inside `.claude-plugin/` fails silently.

---

## 5. How to use it (written as if it already exists)

### One-time: install the engine

```bash
/plugin marketplace add your-org/claude-plugins
/plugin install ds-guard@your-org
# local development instead:  claude --plugin-dir ./ds-guard
```

### In a design system's repo: author a manifest

```bash
/dsguard:init acme
#  → scaffolds design/tokens/ (DTCG stub), design/rules.json, design/references/
```

Fill in `tokens/` (or point at your existing DTCG/Style-Dictionary source) and `rules.json`.

### Generate the enforcement artifact

```bash
/dsguard:generate
#  → emits acme-design-system/ :
#       skills/acme-design-system/SKILL.md   (specific, vocabulary + rules injected)
#       scripts/validate.mjs + validator.config.json   (frozen, self-contained)
#       hooks/hooks.json, .claude-plugin/plugin.json
#  Re-run whenever the manifest changes; SKILL.md can never drift from the tokens.
```

### Publish it for the team

```bash
/plugin marketplace add your-org/design-systems
#  (acme-design-system now appears in the marketplace)
```

### In any app that uses Acme

```bash
/plugin install acme-design-system@your-org
#  → the design-system skill now triggers on any UI work
#  → the PostToolUse hook runs the validator after every edit; errors block "done"

/dsguard:check src                # run the gate manually
/dsguard:review Button            # fresh-context subjective review of a component
```

The app needs only `acme-design-system` — not the engine. The engine is for the people who
author and regenerate design systems.

---

## 6. Required effort

Phased, with an MVP cut line. Estimates assume the validator prototype we already built is the
starting point.

| Phase | Component | Effort | Depends on |
|---|---|---|---|
| MVP | Manifest + `rules.json` schema | 1 d | — |
| MVP | Refactor validator to read allow-lists from manifest | 0.5–1 d | manifest |
| MVP | SKILL template + `generate-skill` script | 1 d | manifest |
| MVP | `/dsguard:generate` command + local test | 0.5 d | above |
| | **MVP subtotal** | **~3–4 d** | |
| v1 | `/dsguard:init`, `/dsguard:check` commands | 0.5 d | MVP |
| v1 | `PostToolUse`/`Stop` hook wiring | 0.5 d | validator |
| v1 | Plugin packaging + per-system bundling (frozen validator) | 0.5–1 d | MVP |
| v1 | DTCG / Style Dictionary → token allow-list generation | 1 d | DTCG source |
| v1 | Docs + one end-to-end test on a sample system | 1 d | all |
| v2 | Reviewer subagent (fresh context) | 0.5–1 d | — |
| v2 | Marketplace + team distribution | 0.5 d | packaging |
| | **Full v1 + v2** | **~6–9 d** | |

**Variance notes:** first-time plugin packaging is slow (~2 h) and fast thereafter (~20 min).
The `rules.json` schema *will* feel incomplete the first time a new system has a rule it can't
express — budget a revisit. The reviewer subagent is the lowest-value, least-reliable piece;
it's correctly last.

---

## 7. Risks & decisions

- **Don't over-design the schema.** Start with the common rules only; lean on `freeformRules` +
  `references/` for everything else. Promote a rule into the schema only after you've seen it in
  two or three different systems. Designing "the universal design-system schema" up front is the
  main way this project bloats.
- **The validator has a known blind spot.** It can't flag a *truly novel* non-colour utility
  (it skips what it can't classify, to avoid false positives). Generating allow-lists from the
  DTCG build narrows this to near-zero by making "is this a real token" an exact lookup — which
  is the v1 DTCG line item.
- **The validator is static-only.** Hierarchy, rhythm, and "is this `serif` really editorial"
  need the reviewer subagent + visual regression, which sit outside this engine.
- **Keep the engine clean.** No design system's quirks (including the Daybreak experiment) may
  leak into the engine or the schema. If a rule only makes sense for one system, it belongs in
  that system's `freeformRules`, never in the engine.

---

## 8. Build sequence

1. Lock the `rules.json` schema (minimal) and the manifest layout.
2. Refactor the prototype validator to read `validator.config.json` instead of embedded sets.
3. Build `generate-skill` (template fill + emit validator config).
4. Wrap as the `ds-guard` plugin; test locally with `--plugin-dir` against a sample manifest.
5. Add the hook and the `init`/`check` commands.
6. Wire DTCG → allow-list generation (turns the validator's warnings into hard errors).
7. Add per-system bundling + marketplace publish.
8. Add the reviewer subagent last.

Validate the whole chain on a small throwaway manifest (Daybreak is fine as that test case) —
but the artifact you keep is the engine, not the test system.
