---
name: daybreak-design-system
description: Enforce the Daybreak design system on every piece of UI you build or review. Use this whenever you generate, edit, or review HTML, JSX, Vue, Svelte, or Astro markup for a Daybreak app — buttons, cards, badges, chips, forms, headings, navigation, layout, pages — or whenever the user mentions Daybreak, the design system, tokens, daybreak.css, or a Tailwind class. Provides the only approved token vocabulary (colors, type scale, spacing, radius, elevation, motion, focus) plus the deterministic validator that must pass before a component is considered done. Always consult this skill before writing UI markup, even if the request doesn't say "design system".
---

# Daybreak design system

Daybreak is warm, welcoming, calm. ~85% of any screen is canvas + surface + ink. Primary
(morning-sky blue) carries actions. Gold is an **accent only** — a fill or indicator, never body
text on light. Light theme for v1.

## Prime directive

**Never hard-code a hex, px, or shadow that isn't a token.** If you need a value that doesn't
exist, stop and add a token first — do not invent one inline. Every approved value below is
already wired into `tailwind.config.theme.extend` and the precompiled `ds/daybreak.css`, so you
reference it by its Tailwind utility, never by its raw value.

## Workflow

**Before building a component**

1. If a contract exists for it in `references/<component>.md` (e.g. `references/badge.md`), read
   that file first and follow it exactly. It is loaded only when needed.
2. Compose from the approved utilities below. Do not reach for default Tailwind palette colors
   (`bg-blue-500`, `text-gray-700`, …), arbitrary values (`text-[14px]`, `bg-[#fff]`), or raw
   hex/px anywhere.

**After building or editing a component**

3. Run the deterministic validator on the files you touched and fix **every** error before
   considering the work done:
   ```bash
   node .claude/skills/daybreak-design-system/scripts/validate-tokens.mjs <file-or-dir> …
   ```
   It exits non-zero on any violation, so it also works as a `PostToolUse`/`Stop` hook or a CI
   gate. The validator is the source of truth for what passes — not your own judgment.
4. For what the validator can't check (visual hierarchy, spacing rhythm, "does this match
   intent"), request a fresh-context review rather than grading your own output. Keep anything
   quantifiable — color, spacing, type scale, shadow — on the validator.

## Approved colour vocabulary

Use only these. Never introduce a new colour — map any new status onto
`success` / `warning` / `danger` / `info`.

**Neutrals (surfaces & ink)** — `bg-canvas`, `bg-surface`, `bg-surface-2`, `border-border`,
`text-ink`, `text-ink-muted`.

**Brand** — `bg-primary` / `text-primary` (actions, links, focus ring), `bg-primary-hover`
(hover/active/pressed), `bg-primary-tint` (soft action bg, selection), `text-primary-on`
(text/icon on a primary fill), `bg-accent` (gold — **fill/indicator only**),
`text-accent-strong` (the only amber allowed as text), `bg-accent-tint`, `bg-support` (sage),
`text-support-strong`. On an accent fill, text is `text-ink` (there is no `accent-on` utility).

**Functional** — `success` (sage), `warning` (amber), `danger` (terracotta; also the live-now
dot), `info` (= primary). Used as `text-*` / `bg-*` / `border-*`.

**Event categories (12)** — each is a text/icon colour + a tint. Colour **never travels alone**:
always pair with the category icon and a text label. Utilities: `bg-cat-<key>`,
`bg-cat-<key>-tint`, `text-cat-<key>`. Keys: `worship`, `prayer`, `music`, `talks`, `study`,
`youth`, `children`, `community`, `outreach`, `charity`, `retreats`, `other`.

## Type scale

Each step is one `text-*` utility that sets size, line-height, and weight together. Use only
these — never default Tailwind sizes (`text-sm`, `text-lg`, `text-2xl`, …) and never arbitrary
sizes (`text-[14px]`).

| Utility | Size | Use |
|---|---|---|
| `text-hero` | 52px / 700 | Marketing hero headline (pair `font-serif`); marketing config only |
| `text-display` | 36px / 800 | Page & big section titles (app screens top out here) |
| `text-h1` | 28px / 700 | Primary headings, stat numbers |
| `text-h2` | 22px / 700 | Card titles, step titles |
| `text-h3` | 18px / 500 | Subheads, event titles in cards |
| `text-body` | 16px / 400 | Default body copy — **body never goes below 16px** |
| `text-meta` | 14px / 400 | Secondary info, timestamps, captions (non-paragraph only) |
| `text-label` | 13px / 500 | Chips, badges, eyebrows, form labels (non-paragraph only) |

Families: `font-sans` (Atkinson Hyperlegible Next — the entire product UI, default on `<body>`)
and `font-serif` (**Lora — editorial only**: blog body, blog/large editorial headlines, the
landing hero headline, the organizer CTA headline). Never use Lora for UI labels, buttons, or
app-screen headings.

## Spacing, radius, elevation, layout

**Spacing** — default Tailwind 4px scale. Common subset: `1`(4) `2`(8) `3`(12) `4`(16) `5`(20)
`6`(24) `8`(32) `12`(48) `16`(64). Rule of thumb: gutters `px-5`, section rhythm `py-12`,
marketing rhythm `py-16`. Prefer flex/grid `gap-*` over per-element margins.

**Radius** — `rounded-md` (8px: buttons, inputs), `rounded-lg` (12px: cards, panels),
`rounded-xl` (16px: hero search, CTA bands), `rounded-full` (chips, badges, avatars, pills).
No other radii.

**Elevation** — flat by default; depth comes from the hairline border, not shadow. Resting cards
& inputs: `border border-border` (or `.hairline`). Only two shadows exist: `shadow-overlay`
(modals, menus, popovers, hover lift) and `shadow-lift` (content floating over imagery, e.g. a
hero card). Nothing else casts a shadow.

**Layout maxima** — content column `max-w-[1180px] mx-auto px-5`; readable text `max-w-measure`
(70ch); long-form article body `max-w-measure-prose` (66ch).

## Motion & focus

- Default transitions `transition-colors duration-150`; cards use `transition-all`.
- Only two named animations: `live-dot` (pulsing live indicator) and `spinner` (loading). Both
  **must** be gated off under `prefers-reduced-motion: reduce`. No other infinite/decorative
  motion exists.
- Focus is global (`:focus-visible` → 2px primary outline, 2px offset) and never removed.
  Interactive components additionally use `ring-2 ring-primary ring-offset-2 ring-offset-canvas`.
- Selection uses `primary.tint`.

## Hard rules (typography & usage)

- **Sentence case everywhere** — headings, buttons, labels, nav. No Title Case, no ALL CAPS
  except the eyebrow.
- **Left-aligned, ragged right. Never justify.** Center only short hero/CTA blocks.
- **Eyebrow** (the one capitalized exception): `text-label uppercase tracking-[0.14em]
  text-accent-strong font-semibold`. Tracking is required — never uppercase without it.
- **Numerals**: stat figures use `text-h1 font-bold tracking-tight`. Use `font-mono` only for
  token/hex/code references in spec UI.
- `text-balance` on hero/headline lines; `text-pretty` on body paragraphs.
- Status is conveyed by **text**, not colour or icon alone — always keep the word.

## Don't

- Don't hard-code a hex, px, or shadow that isn't a token.
- Don't introduce new colours — map onto `success`/`warning`/`danger`/`info`.
- Don't use gold (`accent`) as body text on light; use `text-accent-strong` when amber must be
  text.
- Don't use Lora (`font-serif`) for UI labels, buttons, or app-screen headings.
- Don't add decorative infinite motion beyond `live-dot`.
- Don't remove focus styling.

## Files in this skill

- `scripts/validate-tokens.mjs` — deterministic validator (the gate; run after every build).
- `references/<component>.md` — per-component contracts, loaded only when that component is in
  play. Add one per component as you formalize it (e.g. `references/badge.md`).

## Extending & portability

The validator's allow-lists live at the top of `scripts/validate-tokens.mjs` and are the single
place to update when a token is added. In the mature setup, generate those allow-lists from the
DTCG token build (Style Dictionary) so the validator can never drift from the canonical tokens —
that is also what makes this skill portable to a new project: ship it as a Claude Code plugin
alongside the token package, and a new app gets the rules, the vocabulary, and the gate in one
install.
