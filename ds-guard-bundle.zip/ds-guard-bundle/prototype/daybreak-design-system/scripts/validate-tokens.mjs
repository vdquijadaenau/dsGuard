#!/usr/bin/env node
/**
 * validate-tokens.mjs — deterministic Daybreak design-system gate.
 *
 * Scans UI markup for design drift and exits non-zero on any error, so it works as a
 * Claude Code PostToolUse/Stop hook or a CI step. It catches what a model can't be trusted
 * to self-grade: raw hex, off-scale type, default Tailwind palette colours, disallowed
 * shadows/radii, justified text, and arbitrary values outside the documented allow-list.
 *
 * Usage:
 *   node validate-tokens.mjs <file-or-dir> [<file-or-dir> ...]
 *   node validate-tokens.mjs src components/Button.jsx
 *   node validate-tokens.mjs            # defaults to current directory
 *
 * Exit codes: 0 = clean, 1 = at least one error, 2 = bad invocation.
 *
 * --------------------------------------------------------------------------------------
 * The ALLOW-LISTS below are the single source of truth for this validator. They were
 * derived from tokens.md and typography.md. In the mature setup, GENERATE this block from
 * the DTCG token build (Style Dictionary) so the validator can never drift from the tokens.
 * --------------------------------------------------------------------------------------
 */

import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';

// ---- Allow-lists (derived from tokens.md / typography.md) ----------------------------

const APPROVED_COLORS = new Set([
  // neutrals
  'canvas', 'surface', 'surface-2', 'border', 'ink', 'ink-muted',
  // brand
  'primary', 'primary-hover', 'primary-tint', 'primary-on',
  'accent', 'accent-strong', 'accent-tint', 'support', 'support-strong',
  // functional
  'success', 'warning', 'danger', 'info',
  // generic keywords Tailwind allows everywhere
  'transparent', 'current', 'inherit',
]);

const CATEGORY_KEYS = [
  'worship', 'prayer', 'music', 'talks', 'study', 'youth',
  'children', 'community', 'outreach', 'charity', 'retreats', 'other',
];
for (const k of CATEGORY_KEYS) {
  APPROVED_COLORS.add(`cat-${k}`);
  APPROVED_COLORS.add(`cat-${k}-tint`);
}

// Type scale — the only legal text sizes.
const TYPE_SCALE = new Set(['hero', 'display', 'h1', 'h2', 'h3', 'body', 'meta', 'label']);

// Default Tailwind sizes that must never be used (use the scale above).
const FORBIDDEN_TEXT_SIZES = new Set([
  'xs', 'sm', 'base', 'lg', 'xl',
  '2xl', '3xl', '4xl', '5xl', '6xl', '7xl', '8xl', '9xl',
]);

// `text-*` keywords that are alignment/wrap, not size/colour.
const TEXT_KEYWORDS_OK = new Set([
  'left', 'center', 'right', 'start', 'end',
  'balance', 'pretty', 'wrap', 'nowrap', 'clip', 'ellipsis', 'truncate',
]);
const TEXT_KEYWORDS_BANNED = new Set(['justify']); // never justify

const SHADOW_OK = new Set(['overlay', 'lift', 'none']); // flat by default
const RADIUS_OK = new Set(['md', 'lg', 'xl', 'full', 'none']);

// Default Tailwind palette names — using any of these is "introducing a new colour".
const TW_PALETTE = new Set([
  'slate', 'gray', 'grey', 'zinc', 'neutral', 'stone', 'red', 'orange', 'amber', 'yellow',
  'lime', 'green', 'emerald', 'teal', 'cyan', 'sky', 'blue', 'indigo', 'violet', 'purple',
  'fuchsia', 'pink', 'rose', 'white', 'black',
]);

// Arbitrary values explicitly documented as allowed (extend deliberately).
const ARBITRARY_OK = new Set([
  'tracking-[0.14em]', // eyebrow tracking
  'max-w-[1180px]',    // content container
  'leading-[1.7]',     // long-form article body
]);

// Prefixes that take a colour as their value (longest first so 'ring-offset' beats 'ring').
const COLOR_PREFIXES = [
  'ring-offset', 'placeholder', 'decoration', 'outline', 'border', 'divide', 'stroke',
  'caret', 'ring', 'fill', 'from', 'text', 'via', 'bg', 'to',
].sort((a, b) => b.length - a.length);

// Roots/suffixes that mark a value as "meant to be a Daybreak token". A value that looks like
// one of these but isn't in APPROVED_COLORS is a likely typo or an undefined token — surfaced
// as a warning ("add the token first"), not a hard error.
const APPROVED_ROOTS = new Set([
  'canvas', 'surface', 'border', 'ink', 'primary', 'accent', 'support',
  'success', 'warning', 'danger', 'info', 'cat',
]);
const SEMANTIC_SUFFIXES = ['tint', 'hover', 'strong', 'on', 'muted'];

/** @param {string} v @returns {'approved'|'palette'|'suspect'|'unknown'} */
function classifyColor(v) {
  if (APPROVED_COLORS.has(v)) return 'approved';
  const root = v.split('-')[0];
  if (TW_PALETTE.has(root)) return 'palette';
  if (APPROVED_ROOTS.has(root) || SEMANTIC_SUFFIXES.some((s) => v.endsWith('-' + s))) {
    return 'suspect';
  }
  return 'unknown';
}

const SCAN_EXTENSIONS = new Set(['.html', '.htm', '.jsx', '.tsx', '.vue', '.svelte', '.astro']);
const SKIP_DIRS = new Set([
  'node_modules', '.git', 'dist', 'build', '.next', '.svelte-kit', '.nuxt', 'coverage', 'out',
]);

const HEX_RE = /#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{4}|[0-9a-fA-F]{3})\b/g;
const ARBITRARY_RE = /-\[[^\]]+\]/;
const INLINE_STYLE_RE = /style\s*=/;

// ---- Findings ------------------------------------------------------------------------

/** @typedef {{ file: string, line: number, severity: 'error'|'warn', rule: string, detail: string }} Finding */

/** @param {string} file @param {string} text @returns {Finding[]} */
function checkFile(file, text) {
  /** @type {Finding[]} */
  const out = [];
  const lines = text.split(/\r?\n/);

  lines.forEach((line, i) => {
    const ln = i + 1;

    // 1) Raw hex literals anywhere.
    for (const m of line.matchAll(HEX_RE)) {
      out.push({ file, line: ln, severity: 'error', rule: 'raw-hex',
        detail: `"${m[0]}" — use a Daybreak colour token, never a raw hex.` });
    }

    // 2) Inline style attributes carrying raw px (hex already caught above).
    if (INLINE_STYLE_RE.test(line) && /\b\d+(\.\d+)?px\b/.test(line)) {
      out.push({ file, line: ln, severity: 'error', rule: 'inline-style',
        detail: `inline style uses a raw px value — use spacing-scale / token utilities.` });
    }

    // 3) Class-level checks: tokenize, strip variants, classify.
    for (const raw of line.split(/[\s"'`={}()<>]+/)) {
      if (!raw) continue;
      const cls = raw.includes(':') ? raw.slice(raw.lastIndexOf(':') + 1) : raw; // drop variants
      if (!cls || /^[#./]/.test(cls)) continue;

      // Arbitrary values: allow only the documented set.
      if (ARBITRARY_RE.test(cls)) {
        if (!ARBITRARY_OK.has(cls)) {
          out.push({ file, line: ln, severity: 'error', rule: 'arbitrary-value',
            detail: `"${cls}" — arbitrary value not in the allow-list; use a token.` });
        }
        continue;
      }

      // text-* is overloaded: size | colour | alignment/wrap.
      if (cls === 'text' || cls.startsWith('text-')) {
        const v = cls.slice(5);
        if (!v) continue;
        if (TYPE_SCALE.has(v) || TEXT_KEYWORDS_OK.has(v) || APPROVED_COLORS.has(v)) continue;
        if (TEXT_KEYWORDS_BANNED.has(v)) {
          out.push({ file, line: ln, severity: 'error', rule: 'text-justify',
            detail: `"text-justify" — never justify; left-align, ragged right.` });
        } else if (FORBIDDEN_TEXT_SIZES.has(v)) {
          out.push({ file, line: ln, severity: 'error', rule: 'off-scale-type',
            detail: `"${cls}" — off-scale size; use text-hero/display/h1/h2/h3/body/meta/label.` });
        } else {
          const klass = classifyColor(v);
          if (klass === 'palette') {
            out.push({ file, line: ln, severity: 'error', rule: 'new-colour',
              detail: `"${cls}" — default Tailwind palette colour; use a Daybreak token.` });
          } else if (klass === 'suspect') {
            out.push({ file, line: ln, severity: 'warn', rule: 'unknown-token',
              detail: `"${cls}" — not a defined Daybreak token; add the token first or fix the name.` });
          }
        }
        continue;
      }

      // shadow-* : only overlay / lift / none.
      if (cls === 'shadow' || cls.startsWith('shadow-')) {
        const v = cls === 'shadow' ? '' : cls.slice(7);
        if (!SHADOW_OK.has(v)) {
          out.push({ file, line: ln, severity: 'error', rule: 'disallowed-shadow',
            detail: `"${cls}" — only shadow-overlay and shadow-lift exist (flat by default).` });
        }
        continue;
      }

      // rounded-* : only md / lg / xl / full / none.
      if (cls === 'rounded' || cls.startsWith('rounded-')) {
        const v = cls === 'rounded' ? '' : cls.slice(8);
        if (!RADIUS_OK.has(v)) {
          out.push({ file, line: ln, severity: 'warn', rule: 'non-token-radius',
            detail: `"${cls}" — use rounded-md/lg/xl/full.` });
        }
        continue;
      }

      // Other colour-bearing prefixes: flag palette colours; skip widths/sides/sizes.
      const prefix = COLOR_PREFIXES.find((p) => cls === p || cls.startsWith(p + '-'));
      if (prefix && cls !== prefix) {
        const v = cls.slice(prefix.length + 1);
        const klass = classifyColor(v);
        if (klass === 'palette') {
          out.push({ file, line: ln, severity: 'error', rule: 'new-colour',
            detail: `"${cls}" — default Tailwind palette colour; use a Daybreak token.` });
        } else if (klass === 'suspect') {
          out.push({ file, line: ln, severity: 'warn', rule: 'unknown-token',
            detail: `"${cls}" — not a defined Daybreak token; add the token first or fix the name.` });
        }
        // 'approved' or 'unknown' (border-2, ring-2, from-50%, bg-cover, …) → skip.
      }

      // Lora is editorial-only; can't verify context statically, so surface for review.
      if (cls === 'font-serif') {
        out.push({ file, line: ln, severity: 'warn', rule: 'lora-context',
          detail: `font-serif (Lora) is editorial-only — confirm this isn't UI / app-screen text.` });
      }
    }
  });

  return out;
}

// ---- File collection -----------------------------------------------------------------

/** @param {string} p @param {string[]} acc */
function collect(p, acc) {
  let s;
  try { s = statSync(p); } catch { console.error(`skip (not found): ${p}`); return; }
  if (s.isDirectory()) {
    const base = p.split(/[\\/]/).pop();
    if (SKIP_DIRS.has(base)) return;
    for (const entry of readdirSync(p)) collect(join(p, entry), acc);
  } else if (SCAN_EXTENSIONS.has(extname(p).toLowerCase())) {
    acc.push(p);
  }
}

// ---- Main ----------------------------------------------------------------------------

function main() {
  const args = process.argv.slice(2);
  if (args.includes('--help') || args.includes('-h')) {
    console.log('Usage: node validate-tokens.mjs <file-or-dir> [...]   (default: current dir)');
    process.exit(2);
  }

  const targets = args.length ? args : ['.'];
  /** @type {string[]} */
  const files = [];
  for (const t of targets) collect(t, files);

  if (!files.length) {
    console.log('No UI files found to scan (.html .jsx .tsx .vue .svelte .astro).');
    process.exit(0);
  }

  /** @type {Finding[]} */
  let findings = [];
  for (const f of files) {
    try { findings = findings.concat(checkFile(f, readFileSync(f, 'utf8'))); }
    catch (e) { console.error(`error reading ${f}: ${e.message}`); }
  }

  const errors = findings.filter((f) => f.severity === 'error');
  const warns = findings.filter((f) => f.severity === 'warn');

  // Group by file for readable output.
  const byFile = new Map();
  for (const f of findings) {
    if (!byFile.has(f.file)) byFile.set(f.file, []);
    byFile.get(f.file).push(f);
  }
  for (const [file, fs] of byFile) {
    console.log(`\n${file}`);
    for (const f of fs.sort((a, b) => a.line - b.line)) {
      const tag = f.severity === 'error' ? 'ERROR' : 'warn ';
      console.log(`  ${tag} ${String(f.line).padStart(4)}  [${f.rule}] ${f.detail}`);
    }
  }

  console.log(
    `\nScanned ${files.length} file(s): ${errors.length} error(s), ${warns.length} warning(s).`,
  );
  process.exit(errors.length ? 1 : 0);
}

main();
